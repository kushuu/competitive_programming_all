// https://leetcode.com/problems/basic-calculator-ii

class Solution(object):
    def calculate(self, s):
        """
        :type s: str
        :rtype: int
        """
        return eval(s)
        