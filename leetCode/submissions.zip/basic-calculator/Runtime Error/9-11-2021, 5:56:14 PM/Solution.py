// https://leetcode.com/problems/basic-calculator

class Solution:
    def calculate(self, s: str) -> int:
        return eval(s)